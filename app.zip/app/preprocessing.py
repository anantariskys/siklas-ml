import re
import nltk
from Sastrawi.Stemmer.StemmerFactory import StemmerFactory
from nltk.corpus import stopwords

# Download stopwords (sekali saja)
nltk.download('stopwords')

# Stopwords Bahasa Indonesia
stop_words = set(stopwords.words('indonesian'))

# Stemmer Sastrawi
factory = StemmerFactory()
stemmer = factory.create_stemmer()

def preprocess_text(text: str) -> str:
    # Lowercase
    text = text.lower()
    
    # Hapus angka & tanda baca
    text = re.sub(r'[^a-zA-Z\s]', '', text)
    
    # Tokenisasi (split by spasi)
    tokens = text.split()
    
    # Stopword removal
    tokens = [w for w in tokens if w not in stop_words]
    
    # Stemming
    tokens = [stemmer.stem(w) for w in tokens]
    
    return " ".join(tokens)
