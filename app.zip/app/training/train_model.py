import os
import pickle
import pandas as pd
from tqdm import tqdm
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import SVC
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    classification_report, confusion_matrix
)
import seaborn as sns
import matplotlib.pyplot as plt
from app.preprocessing import preprocess_text

# Path simpan model
MODEL_DIR = os.path.join(os.path.dirname(__file__), "model")
os.makedirs(MODEL_DIR, exist_ok=True)
MODEL_PATH = os.path.join(MODEL_DIR, "svm.pkl")
VECTORIZER_PATH = os.path.join(MODEL_DIR, "vectorizer.pkl")

# Load dataset
dataset_path = os.path.join(os.path.dirname(__file__), "dataset_skripsi.csv")
print("📂 Loading dataset...")
data = pd.read_csv(dataset_path)

# Preprocessing
print("📝 Preprocessing...")
tqdm.pandas()
data["teks"] = (data["Judul Skripsi"] + " " + data["Abstrak"]).progress_apply(preprocess_text)

X = data["teks"]
y = data["Bidang Penelitian"]

# Buang kelas yang punya data terlalu sedikit (min 2 data)
print("🔍 Mengecek distribusi kelas...")
class_counts = y.value_counts()
valid_classes = class_counts[class_counts > 1].index
data = data[data["Bidang Penelitian"].isin(valid_classes)]

X = data["teks"]
y = data["Bidang Penelitian"]

print("Jumlah data setelah filter:", len(data))
print("Distribusi kelas:\n", y.value_counts())

# Train-test split (stratified)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# TF-IDF
print("🔡 TF-IDF...")
vectorizer = TfidfVectorizer(
    max_features=10000,
    ngram_range=(1, 2),
    sublinear_tf=True
)
X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)

# GridSearchCV untuk optimasi
print("⚙️ Hyperparameter tuning...")
param_grid = {
    "C": [0.1, 1, 10],
    "kernel": ["linear", "rbf"],
    "gamma": ["scale", "auto"]
}

grid = GridSearchCV(
    SVC(probability=True),
    param_grid,
    cv=5,
    scoring="f1_weighted",
    n_jobs=-1,
    verbose=2
)
grid.fit(X_train_vec, y_train)

print("✅ Best Params:", grid.best_params_)
print("✅ Best Score :", grid.best_score_)

svm = grid.best_estimator_

# Evaluasi
print("🔎 Evaluasi...")
y_pred = svm.predict(X_test_vec)
print("\n📊 Evaluasi Model SVM")
print("Akurasi :", accuracy_score(y_test, y_pred))
print("Precision:", precision_score(y_test, y_pred, average="weighted"))
print("Recall   :", recall_score(y_test, y_pred, average="weighted"))
print("F1-score :", f1_score(y_test, y_pred, average="weighted"))
print("\nClassification Report:\n", classification_report(y_test, y_pred))

cm = confusion_matrix(y_test, y_pred, labels=svm.classes_)
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
            xticklabels=svm.classes_, yticklabels=svm.classes_)
plt.title("Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.show()

# Simpan model
print("💾 Menyimpan model...")
with open(MODEL_PATH, "wb") as f:
    pickle.dump(svm, f)
with open(VECTORIZER_PATH, "wb") as f:
    pickle.dump(vectorizer, f)

print(f"✅ Model disimpan di {MODEL_PATH}")
print(f"✅ Vectorizer disimpan di {VECTORIZER_PATH}")
